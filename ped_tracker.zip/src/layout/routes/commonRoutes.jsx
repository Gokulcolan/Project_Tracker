import EditProfile from "../../pages/auth/EditProfile";

const CommonRoutes = [
  {
    path: "/editProfile",
    element: <EditProfile />,
  },
];

export default CommonRoutes;
