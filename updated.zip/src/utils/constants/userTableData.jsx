export const userProjectListTableHead = [
    {
        label: "Project Name", id: "project_name"
    },
    {
        label: "Plant", id: "plant"
    },
    {
        label: "Start Date", id: "start_date"
    },
    {
        label: "End Date", id: "enddate"
    },
    {
        label: "Team Members", id: "teammembers.name"
    },
    {
        id: "actions",
        label: "Actions",
        type: "actions",
        actions: [
            { key: "view", label: "View", color: "primary" },
            // { key: "edit", label: "Edit", color: "secondary" },
            // { key: "delete", label: "Delete", color: "error" },
        ],
    },
]

export const userProjectMilestoneSettingTableHead = [
    {
        label: "Project Name", id: "project_name"
    },
    {
        label: "Plant", id: "plant"
    },

    {
        label: "Start Date", id: "start_date"
    },
    {
        label: "End Date", id: "enddate"
    },

    {
        id: "actions",
        label: "Actions",
        type: "actions",
        actions: [
            { key: "view", label: "Set Milestone", color: "primary" },
            { key: "edit", label: "View Milestone", color: "secondary" },
            // { key: "delete", label: "Delete", color: "error" },
        ],
    },
]

export const userViewMilestoneProjectTableHead = [
    {
        label: "Milestone", id: "name"
    },
    {
        label: "Start Date", id: "startdate"
    },
    {
        label: "End Date", id: "enddate"
    },
    {
        label: "Remarks", id: "remarks"
    },
    {
        label: "Status", id: "status"
    },
    {
        id: "actions",
        label: "Actions",
        type: "actions",
        actions: [
            
            { key: "view", label: "Set Milestone", color: "primary" },
            { key: "edit", label: "Update Milestone", color: "secondary" },
            // { key: "delete", label: "Delete", color: "error" },
        ],
    },
]

export const managerViewMilestoneProjectTableHead = [
    {
        label: "Milestone", id: "name"
    },
    {
        label: "Start Date", id: "startdate"
    },
    {
        label: "End Date", id: "enddate"
    },
    {
        label: "Remarks", id: "remarks"
    },
    {
        label: "Status", id: "status"
    },

]


export const managerProjectListTableHead = [
    {
        label: "Project Name", id: "project_name"
    },
    {
        label: "Plant", id: "plant"
    },
    // {
    //     label: "Product Unit", id: "product_unit"
    // },
    // {
    //     label: "Start Date", id: "start_date"
    // },
    // {
    //     label: "End Date", id: "enddate"
    // },
    {
        label: "Team Members", id: "teammembers.name"
    },
    {
        id: "actions",
        label: "Actions",
        type: "actions",
        actions: [
            { key: "view", label: "View", color: "primary" },
            // { key: "edit", label: "Edit", color: "secondary" },
            // { key: "delete", label: "Delete", color: "error" },
        ],
    },
]