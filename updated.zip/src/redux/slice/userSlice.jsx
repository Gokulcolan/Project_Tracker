import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
    name: "user",
    initialState: {
        userAddProjectDetail: [],
        userAddProjectIsLoading: false,
        userProjectListDetail: [],
        userProjectListIsLoading: false,
        userViewSingleProjectDetail: [],
        userViewSingleProjectIsLoading: false,
        userAddMilestoneDetail: [],
        userAddMilestoneIsLoading: false,
        getMilestonesByProjectForUserDetail: [],
        getMilestonesByProjectForUserIsLoading: false,
        updateMilestonesByProjectForUserDetail: [],
        updateMilestonesByProjectForUserIsLoading: false,
        getMilestonesChartByProjectForUserDetail: [],
        getMilestonesChartByProjectForUserIsLoading: false,
    },
    reducers: {
        userAddProjectReducer: (state, { payload }) => {
            const { apiData, isLoading } = payload;
            state.userAddProjectDetail = apiData;
            state.userAddProjectIsLoading = isLoading;
        },
        userProjectListReducer: (state, { payload }) => {
            const { apiData, isLoading } = payload;
            state.userProjectListDetail = apiData;
            state.userProjectListIsLoading = isLoading;
        },
        userViewSingleProjectReducer: (state, { payload }) => {
            const { apiData, isLoading } = payload;
            state.userViewSingleProjectDetail = apiData;
            state.userViewSingleProjectIsLoading = isLoading;
        },

        userAddMilestoneReducer: (state, { payload }) => {
            const { apiData, isLoading } = payload;
            state.userAddMilestoneDetail = apiData;
            state.userAddMilestoneIsLoading = isLoading;
        },

        getMilestonesByProjectForUserReducer: (state, { payload }) => {
            const { apiData, isLoading } = payload;
            state.getMilestonesByProjectForUserDetail = apiData;
            state.getMilestonesByProjectForUserIsLoading = isLoading;
        },

        updateMilestonesByProjectForUserReducer: (state, { payload }) => {
            const { apiData, isLoading } = payload;
            state.updateMilestonesByProjectForUserDetail = apiData;
            state.updateMilestonesByProjectForUserIsLoading = isLoading;
        },
        
        getMilestonesChartByProjectForUserReducer: (state, { payload }) => {
            const { apiData, isLoading } = payload;
            state.getMilestonesChartByProjectForUserDetail = apiData;
            state.getMilestonesChartByProjectForUserIsLoading = isLoading;
        },
    },
})

export const { userAddProjectReducer, userProjectListReducer, userViewSingleProjectReducer, userAddMilestoneReducer, getMilestonesByProjectForUserReducer, updateMilestonesByProjectForUserReducer, getMilestonesChartByProjectForUserReducer } = userSlice.actions;

export const userSelector = (state) => state.user;

export const userReducer = userSlice.reducer;
