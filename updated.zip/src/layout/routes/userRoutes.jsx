import UserHome from '../../pages/user/Home'
import RootLayout from '../nav/rootLayout'
import AddNewProject from '../../componenets/manager/AddProjects'
import ProjectList from '../../pages/user/ProjectList'
import ProjectOverview from '../../componenets/user/ProjectOverview'
import ViewMilestone from '../../componenets/user/UpdateMilestone'

const UserRoutes = [
  {
    path: "/userDashboard",
    element: <RootLayout />,
    children: [
      {
        path: "home",
        element: <UserHome />,
      },
      {
        path: "projects",
        element: <ProjectList />,
      },
      // {
      //   path: "mileStones",
      //   element: <MileStones />,
      // },
      {
        path: "addNewProject",
        element: <AddNewProject />,
      },
      {
        path: "viewProject",
        element: <ProjectOverview />,
      },
      // {
      //   path: "addMilestones",
      //   element: <AddMileStone />,
      // },
      {
        path: "viewMilestones",
        element: <ViewMilestone />,
      },

    ],
  }
]

export default UserRoutes