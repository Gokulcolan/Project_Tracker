import React from 'react'
import Login from '../../pages/auth/Login'
import { Outlet } from 'react-router-dom'

const AuthRoutes = [
    {
        path: "/",
        element: <Outlet />,
        children: [
            {
                path: "/", // Corrected path
                element: <Login />,
            },
            // {
            //   path: "forgot-password", // Corrected path
            //   element: <ForgotPassword />,
            // },
        ],
    }
]

export default AuthRoutes