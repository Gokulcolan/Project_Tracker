import React from 'react'
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Box, Typography } from "@mui/material";

const DonutChart = ({ milestones = [] }) => {

    // Status → color mapping
    const STATUS_COLORS = {
        "Completed": "#4caf50",
        "In Progress": "#ff9800",
        "Not Started": "#9e9e9e",
        "Delayed": "#f44336"
    };

    const statusCounts = milestones.reduce((acc, m) => {
        const status = m.status || "Not Started";
        acc[status] = (acc[status] || 0) + 1;
        return acc;
    }, {});

    // Convert to Recharts-friendly format
    const chartData = Object.entries(statusCounts).map(([status, count]) => ({
        name: status,
        value: count,
        color: STATUS_COLORS[status] || "#607d8b"
    }));
    return (
        <Box sx={{ width: "100%", height: 400 }}>
            <Typography variant="h6" textAlign="center" mb={2}>
                Milestone Status Overview
            </Typography>

            <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                        data={chartData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={70}
                        outerRadius={120}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                        {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36} />
                </PieChart>
            </ResponsiveContainer>
        </Box>
    )
}

export default DonutChart


