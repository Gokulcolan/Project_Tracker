import {
  Box,
  Card,
  Typography,
  Grid,
  Divider,
} from "@mui/material";
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import EventIcon from '@mui/icons-material/Event';
import PeopleIcon from '@mui/icons-material/People';
import BusinessIcon from '@mui/icons-material/Business';
import InventoryIcon from '@mui/icons-material/Inventory';
import CategoryIcon from '@mui/icons-material/Category';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import LabelImportantIcon from '@mui/icons-material/LabelImportant';

const ProjectOverviewCard = ({ project }) => {
  return (
    <Card
      elevation={4}
      sx={{
        // maxWidth: 500,
        // mx: "auto",
        my: 4,
        p: 3,
        borderRadius: 4,
        backgroundColor: "#f9fafb",
      }}
    >
      <Typography variant="h5" fontWeight={700} gutterBottom>
        Project Overview
      </Typography>

      <Divider sx={{ my: 2 }} />

      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <InfoRow icon={<LabelImportantIcon color="primary" />} label="Project ID" value={project.projectId} />
          <InfoRow icon={<AccountBoxIcon color="primary" />} label="Project Name" value={project.projectName} />
          <InfoRow icon={<PeopleIcon color="primary" />} label="Project Manager" value={project.projectManager} />
          <InfoRow icon={<PeopleIcon color="primary" />} label="Project Sponsor" value={project.projectSponsor} />
          <InfoRow icon={<EventIcon color="primary" />} label="Start Date" value={project.startDate} />
          <InfoRow icon={<EventIcon color="error" />} label="Deadline" value={project.deadline} />
        </Grid>
        <Grid item xs={12} sm={6}>
          <InfoRow icon={<PeopleIcon color="secondary" />} label="Team Members" value={project.teamMember} />
          <InfoRow icon={<BusinessIcon color="success" />} label="Business Unit" value={project.totalRate} />
          <InfoRow icon={<InventoryIcon color="warning" />} label="Product" value={project.product} />
          <InfoRow icon={<BusinessIcon color="info" />} label="Plant" value={project.loggedHours} />
          <InfoRow icon={<CategoryIcon />} label="Category" value={project.billingType} />
          <InfoRow
            icon={<InfoOutlinedIcon />}
            label="Description"
            value={project.description}
            multiline
          />
        </Grid>
      </Grid>
    </Card>
  );
};

const InfoRow = ({ icon, label, value }) => (
  <Box display="flex" alignItems="center" mb={1}>
    <Box display="flex" alignItems="center" minWidth={120} mr={2}>
      {icon && <Box mr={1}>{icon}</Box>}
      <Typography variant="subtitle2" fontWeight={600} noWrap>
        {label}:
      </Typography>
    </Box>
    <Typography
      variant="body2"
      color="text.secondary"
      noWrap
      sx={{
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        flex: 1,
      }}
    >
      {value || "-"}
    </Typography>
  </Box>
);


export default ProjectOverviewCard;
