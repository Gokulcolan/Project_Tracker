import React from "react";
import {
    Box,
    Card,
    CardContent,
    CardHeader,
    Divider,
    Typography,
    Stack,
    Button,
    TextField,
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";
import { useFormik } from "formik";
import * as Yup from "yup";
import FormikTextField from "../../common/Fields/formikTextField";
import FormikDropdown from "../../common/Fields/formikDropDown";
import CelebrationIcon from "@mui/icons-material/Celebration";
import { useDispatch } from "react-redux";
import { userAddProjectApi } from "../../../redux/action/userAction";


const priorities = [
    { value: "Low", label: "Low" },
    { value: "Medium", label: "Medium" },
    { value: "High", label: "High" },
    { value: "Critical", label: "Critical" },
];

const categories = [
    { value: "Web App", label: "Web App" },
    { value: "Mobile App", label: "Mobile App" },
    { value: "Internal Tool", label: "Internal Tool" },
    { value: "Research", label: "Research" },
];

const teammember = [
    { value: "Gokul", label: "Gokul" },
    { value: "Surya", label: "Surya" },
    { value: "Bala", label: "Bala" },
    { value: "Kani", label: "Kani" },
    { value: "sharon", label: "sharon" },
];

const validationSchema = Yup.object({
    project_id: Yup.string().required("Project ID is required"),
    project_name: Yup.string().required("Project Name is required"),
    category: Yup.string().required("category is required"),
    product: Yup.string().required("product is required"),
    start_date: Yup.date().required("Start date is required"),
});

const twoPerRowStyles = {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(500px,2fr))",
    gap: 4,
};

const AddProjectForm = () => {
    const dispatch = useDispatch()

    const formik = useFormik({
        initialValues: {
            project_name: "",
            business_unit: "",
            plant: "",
            project_id: "",
            project_sponsor: "",
            project_manager: "",
            product: "",
            category: "",
            start_date: dayjs(),
            enddate: null,
            project_description: "",
            teammember: ""
        },
        validationSchema,
        onSubmit: (values) => {
            const payload = {
                ...values,
                start_date: dayjs(values.start_date).format("YYYY-MM-DD"),
                enddate: values.enddate ? dayjs(values.enddate).format("YYYY-MM-DD") : null,
            };
            dispatch(userAddProjectApi(payload))
        },
    });

    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <Card elevation={6} sx={{ maxWidth: 1200, margin: "auto", borderRadius: 4 }}>
                <CardHeader
                    avatar={<CelebrationIcon color="primary" />}
                    title={
                        <Typography variant="h5" fontWeight={700} color="primary.dark">
                            Add New Project
                        </Typography>
                    }
                    sx={{ pb: 0, textAlign: { xs: "center", sm: "left" } }}
                />

                <CardContent>
                    <Box component="form" noValidate onSubmit={formik.handleSubmit} sx={twoPerRowStyles}>
                        {/* First Column */}
                        <FormikTextField formik={formik} name="project_name" label="Project Name" required />
                        <FormikTextField formik={formik} name="business_unit" label="Business Unit" />
                        <FormikTextField formik={formik} name="plant" label="Plant Name" />
                        <FormikTextField formik={formik} name="project_id" label="Project ID" required />
                        <FormikTextField formik={formik} name="project_sponsor" label="Project Sponsor" />
                        <FormikTextField formik={formik} name="project_manager" label="Project Manager" />

                        <DatePicker
                            label="Start Date"
                            value={formik.values.start_date}
                            onChange={(value) => formik.setFieldValue("start_date", value)}
                            renderInput={(params) => (
                                <TextField {...params} fullWidth margin="normal" />
                            )}
                        />

                        <DatePicker
                            label="Expected End Date"
                            value={formik.values.enddate}
                            onChange={(value) => formik.setFieldValue("enddate", value)}
                            renderInput={(params) => (
                                <FormikTextField {...params} formik={formik} name="enddate" />
                            )}
                        />

                        <FormikDropdown
                            formik={formik}
                            name="category"
                            label="category"
                            options={categories}
                            required
                        />

                        <FormikDropdown
                            formik={formik}
                            name="product"
                            label="product"
                            options={priorities}
                            required
                        />

                        <FormikDropdown
                            formik={formik}
                            name="teammember"
                            label="Team Members"
                            options={teammember}
                            required
                        />

                        <FormikTextField
                            formik={formik}
                            name="project_description"
                            label="Project project_description"
                            multiline
                            rows={3}
                        />

                        <Divider sx={{ my: 4 }} />

                        {/* Action Buttons */}
                        <Stack direction="row" spacing={2} justifyContent="flex-end">
                            <button type="button" onClick={formik.handleReset} className="cancel-btn">
                                Cancel
                            </button>
                            <button type="submit" className="submit-btn">
                                Create Project
                            </button>
                        </Stack>
                    </Box>



                </CardContent>
            </Card>
        </LocalizationProvider>
    );
};

export default AddProjectForm;
