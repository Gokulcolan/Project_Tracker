import React, { useState } from "react";
import {
    Box,
    IconButton,
    TextField,
    Grid,
    Button,
    Paper,
    Typography,
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import DeleteIcon from "@mui/icons-material/Delete";
import { userAddMilestoneApi } from "../../../redux/action/userAction";
import { useDispatch } from "react-redux";
import { useLocation } from "react-router-dom";

const AddMileStone = () => {
    const dispatch = useDispatch()
    const { state } = useLocation();
    const projectRefId = state?.projectRefId;
    const [milestones, setMilestones] = useState([
        { name: "", startdate: null, enddate: null, remarks: "" },
    ]);

    const handleChange = (index, field, value) => {
        setMilestones((prev) =>
            prev.map((item, i) => (i === index ? { ...item, [field]: value } : item))
        );
    };

    const addMilestone = () => {
        setMilestones((prev) => [...prev, { name: "", startdate: null, enddate: null, remarks: "" }]);
    };

    const removeMilestone = (index) => {
        setMilestones((prev) => prev.filter((_, i) => i !== index));
    };

    const formatDate = (date) => {
        if (!date) return null;
        const d = new Date(date);
        const year = d.getFullYear();
        const month = `${d.getMonth() + 1}`.padStart(2, "0");
        const day = `${d.getDate()}`.padStart(2, "0");
        return `${year}-${month}-${day}`;
    };

    const handleSave = () => {
        const hasErrors = milestones.some(
            (m) => !m.name || !m.startdate || !m.enddate
        );

        if (hasErrors) {
            alert("Please fill in Milestone Name, Start Date, and End Date for all entries.");
            return;
        }
        const payload = milestones.map((m) => ({
            name: m.name,
            startdate: m.startdate ? formatDate(m.startdate) : null,
            enddate: m.enddate ? formatDate(m.enddate) : null,
            remarks: m.remarks,
        }));

        dispatch(userAddMilestoneApi(payload, projectRefId));
    };

    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Box sx={{ maxWidth: 1100, mx: "auto", mt: 2, px: 1, overflowX: "auto" }}>
                <Typography variant="h6" fontWeight="bold" textAlign="center" mb={2}>
                    Add Milestone
                </Typography>

                {Array.isArray(milestones) && milestones?.map((m, index) => (
                    <Paper
                        key={index}
                        sx={{
                            mb: 1.5,
                            px: 2,
                            py: 1.5,
                            background: "linear-gradient(135deg, #f0f4f8 0%, #ffffff 100%)",
                            borderLeft: "5px solid #4caf50",
                            borderRadius: 3,
                            boxShadow: "0 4px 10px rgba(0, 0, 0, 0.05)",
                            transition: "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out",
                            "&:hover": {
                                transform: "scale(1.01)",
                                boxShadow: "0 6px 14px rgba(0, 0, 0, 0.1)",
                            },
                        }}
                    >

                        <Grid container spacing={1} alignItems="center">
                            <Grid item xs={12} sm={2.5}>
                                <TextField
                                    label="Milestone Name"
                                    value={m.name}
                                    onChange={(e) => handleChange(index, "name", e.target.value)}
                                    fullWidth
                                    size="small"
                                    required
                                />
                            </Grid>
                            <Grid item xs={12} sm={2}>
                                <DatePicker
                                    label="startdate Date"
                                    value={m.startdate}
                                    onChange={(date) => handleChange(index, "startdate", date)}
                                    slotProps={{ textField: { size: 'small', fullWidth: true, required: true } }}
                                />


                            </Grid>
                            <Grid item xs={12} sm={2}>
                                <DatePicker
                                    label="enddate Date"
                                    value={m.enddate}
                                    onChange={(date) => handleChange(index, "enddate", date)}
                                    slotProps={{ textField: { size: 'small', fullWidth: true, required: true } }}
                                />
                            </Grid>

                            <Grid item xs={12} sm={4.5}>
                                <TextField
                                    label="Remarks"
                                    value={m.remarks}
                                    onChange={(e) => handleChange(index, "remarks", e.target.value)}
                                    fullWidth
                                    size="small"
                                    multiline
                                    minRows={1}
                                    maxRows={2}
                                />
                            </Grid>
                            <Grid item xs={12} sm={1} sx={{ textAlign: "right" }}>
                                <IconButton onClick={addMilestone} color="primary" size="small">
                                    <AddCircleIcon fontSize="small" />
                                </IconButton>
                                {milestones.length > 1 && (
                                    <IconButton onClick={() => removeMilestone(index)} color="error" size="small">
                                        <DeleteIcon fontSize="small" />
                                    </IconButton>
                                )}
                            </Grid>
                        </Grid>

                    </Paper>
                ))}

                <Box textAlign="right" mt={2}>
                    <Button
                        variant="contained"
                        color="success"
                        size="medium"
                        onClick={handleSave}
                    >
                        Save All Milestones
                    </Button>
                </Box>
            </Box>
        </LocalizationProvider>
    );
};

export default AddMileStone;
