import { useDispatch, useSelector } from "react-redux";
import ProjectOverviewCard from "../../common/cards/projectOverviewCard"
import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { getMilestonesByProjectForUserApi, userViewSingleProjectApi } from "../../../redux/action/userAction";
import { userSelector } from "../../../redux/slice/userSlice";
import AddMilestoneModal from "../../common/modal/addMilestoneModal";
import CommonTable from "../../common/Table/commonTable";
import { userViewMilestoneProjectTableHead } from "../../../utils/constants/userTableData";
import UpdateMilestoneModal from "../../common/modal/updateMilestoneModal";
import { Box } from "@mui/material";
import DonutChart from "../../common/chart/DonutChart";



const ProjectOverview = ({ project }) => {
    const { state } = useLocation();
    const dispatch = useDispatch()
    const [open, setOpen] = useState(false);
    const [openUpdate, setOpenUpdate] = useState(false);

    const [selectedMilestone, setSelectedMilestone] = useState(null);
    const projectRefId = state?.projectRefId;
    const { userViewSingleProjectDetail, getMilestonesByProjectForUserDetail } = useSelector(userSelector);


    console.log(projectRefId, "projectRefId")
    console.log(userViewSingleProjectDetail, "userViewSingleProjectDetail")


    useEffect(() => {
        if (projectRefId) {
            dispatch(userViewSingleProjectApi(projectRefId));
            dispatch(getMilestonesByProjectForUserApi(projectRefId));
        }
    }, [dispatch, projectRefId]);


    const handleAddMilestone = () => {
        setSelectedMilestone({
            projectRefId: projectRefId,
            // milestoneRefId: row.milestone_ref_id,
        });
        setOpen(true);
    }

    const handleActionClick = (action, row) => {
        console.log(row, "row")
        switch (action) {
            // case "view":
            //     navigate("/userDashboard/addMilestones", {
            //         state: { projectRefId: row.project_ref_id },
            //     });
            //     break;
            case "edit":
                setSelectedMilestone({
                    projectRefId: projectRefId,
                    milestoneRefId: row.milestone_ref_id,
                    milestoneData: row,
                });
                setOpenUpdate(true);
                break;
            // case "delete":
            //     if (window.confirm(`Are you sure you want to delete "${row.project_name}"?`)) {
            //         console.log("DELETE", row);
            //         // dispatch(deleteProjectApi(row.id))
            //     }
            //     break;
            default:
                break;
        }
    };

    const milestones = [
        { name: "Planning", status: "Completed" },
        { name: "Design", status: "In Progress" },
        { name: "Development", status: "In Progress" },
        { name: "Testing", status: "Not Started" },
        { name: "Deployment", status: "Delayed" },
    ];

    return (
        <div>
            <Box display="flex" justifyContent="flex-end" >

                <button className="submit-btn" onClick={handleAddMilestone} >Add Milestone</button>
            </Box>
            <div style={{display:"flex"}}>
                <ProjectOverviewCard
                    project={{
                        projectId: userViewSingleProjectDetail?.data?.project_id,
                        progress: 40, // Adjust or calculate if needed
                        customerName: userViewSingleProjectDetail?.data?.project_sponsor,
                        customerLink: "", // Add if available
                        billingType: userViewSingleProjectDetail?.data?.category,
                        totalRate: userViewSingleProjectDetail?.data?.business_unit,
                        status: "In Progress", // Add if available
                        dateCreated: userViewSingleProjectDetail?.data?.created_at?.split("T")[0],
                        startDate: userViewSingleProjectDetail?.data?.start_date,
                        deadline: userViewSingleProjectDetail?.data?.enddate,
                        estimatedHours: "90:00", // Replace with actual if available
                        loggedHours: userViewSingleProjectDetail?.data?.plant,
                        description: userViewSingleProjectDetail?.data?.project_description,
                        projectManager: userViewSingleProjectDetail?.data?.project_manager,
                        projectName: userViewSingleProjectDetail?.data?.project_name,
                        projectSponsor: userViewSingleProjectDetail?.data?.project_sponsor,
                        teamMember: userViewSingleProjectDetail?.data?.teammember,
                        product: userViewSingleProjectDetail?.data?.product,
                    }}
                />
                <DonutChart milestones={milestones} />
            </div>

            <CommonTable
                columns={userViewMilestoneProjectTableHead}
                data={
                    Array.isArray(getMilestonesByProjectForUserDetail?.data?.milestones)
                        ? getMilestonesByProjectForUserDetail.data.milestones
                        : []
                }
                onActionClick={handleActionClick}
            />
            <AddMilestoneModal
                openModal={open}
                setOpenModal={() => setOpen(false)}
                // projectRefId={selectedMilestone?.projectRefId}
                projectRefId={selectedMilestone?.projectRefId ?? projectRefId}
            />
            <UpdateMilestoneModal
                openModal={openUpdate}
                setOpenModal={() => setOpenUpdate(false)}
                projectRefId={selectedMilestone?.projectRefId}
                milestoneRefId={selectedMilestone?.milestoneRefId}
                milestoneData={selectedMilestone?.milestoneData}
            />
        </div>
    )
}

export default ProjectOverview