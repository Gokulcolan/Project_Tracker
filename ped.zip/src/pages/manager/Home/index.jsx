import React from 'react'

const ManagerHome = () => {
  return (
    <div>ManagerHome</div>
  )
}

export default ManagerHome