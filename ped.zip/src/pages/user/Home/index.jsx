import React, { useEffect } from 'react'
import StatCards from '../../../componenets/common/cards'
import CommonTable from '../../../componenets/common/Table/commonTable'
import { userProjectListTableHead } from '../../../utils/constants/userTableData'
import { useNavigate } from 'react-router-dom'
import { userProjectListApi } from '../../../redux/action/userAction'
import { useDispatch, useSelector } from 'react-redux'
import { userSelector } from '../../../redux/slice/userSlice'
import { Box } from '@mui/material'

const UserHome = () => {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const { userProjectListDetail } = useSelector(userSelector)

    console.log(userProjectListDetail, "userProjectListDetail");


    const handleAddNewProject = () => {
        navigate("/userDashboard/addNewProject")
    }
    useEffect(() => {
        dispatch(userProjectListApi())
    }, [])

    const handleActionClick = (action, row) => {
        switch (action) {
            case "view":
                navigate("/userDashboard/viewProject", {
                    state: { projectRefId: row.project_ref_id },
                });
                break;
            case "edit":
                navigate(`/userDashboard/editProject/${row.project_ref_id}`);
                break;
            case "delete":
                if (window.confirm(`Are you sure you want to delete "${row.project_name}"?`)) {
                    console.log("DELETE", row);
                    // dispatch(deleteProjectApi(row.id))
                }
                break;
            default:
                break;
        }
    };

    return (
        <div>
            <div className="card-container">
                <StatCards
                    title="Total No of Projects"
                    details={{
                        count: 10,
                    }}
                />
                <StatCards
                    title="Completed Projects"
                    details={{
                        count: 8,
                    }}
                />
                <StatCards
                    title="Pending Projects"
                    details={{
                        count: 2,
                    }}
                />
            </div>
            <br />

            {/* <button className="submit-btn" onClick={handleAddNewProject}> + Add New Project</button> */}

            <Box display="flex" justifyContent="flex-end">
                <button onClick={handleAddNewProject} className="submit-btn">+ Add New Project</button>
            </Box>

            <CommonTable columns={userProjectListTableHead} data={userProjectListDetail?.data?.projects} onActionClick={handleActionClick} />
        </div>
    )
}

export default UserHome