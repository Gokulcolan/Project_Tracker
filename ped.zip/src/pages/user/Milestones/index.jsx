import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { userSelector } from '../../../redux/slice/userSlice';
import { userProjectListApi } from '../../../redux/action/userAction';
import CommonTable from '../../../componenets/common/Table/commonTable';
import { userProjectMilestoneSettingTableHead } from '../../../utils/constants/userTableData';

const MileStones = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { userProjectListDetail } = useSelector(userSelector);
  console.log(userProjectListDetail, "userProjectListDetail")

  // const handleAddNewProject = () => {
  //     navigate("/userDashboard/viewProject");
  // };

  useEffect(() => {
    dispatch(userProjectListApi());
  }, []);

  const handleActionClick = (action, row) => {
    switch (action) {
      case "view":
        navigate("/userDashboard/addMilestones", {
          state: { projectRefId: row.project_ref_id },
        });
        break;
      case "edit":
        navigate("/userDashboard/viewMilestones", {
          state: { projectRefId: row.project_ref_id },
        });
        break;
      // case "delete":
      //     if (window.confirm(`Are you sure you want to delete "${row.project_name}"?`)) {
      //         console.log("DELETE", row);
      //         // dispatch(deleteProjectApi(row.id))
      //     }
      //     break;
      default:
        break;
    }
  };
  return (
    <div>
      {/* <button className="submit-btn" onClick={handleAddNewProject}>+ Add New Project</button> */}
      <CommonTable
        columns={userProjectMilestoneSettingTableHead}
        data={userProjectListDetail?.data?.projects ?? []}
        onActionClick={handleActionClick}
      />
    </div>
  )
}

export default MileStones