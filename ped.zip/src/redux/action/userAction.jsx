import { Apiservice } from "../api/apiService";
import { adminAddUserReducer } from "../slice/adminSlice";
import { getMilestonesByProjectForUserReducer, updateMilestonesByProjectForUserReducer, userAddMilestoneReducer, userAddProjectReducer, userProjectListReducer, userViewSingleProjectReducer } from "../slice/userSlice";

export function apiHelper(apiReducer, method, apiURL, data = "") {
    return async (dispatch) => {
        dispatch(apiReducer({ isLoading: true }));
        Apiservice(method, apiURL, data)
            .then((e) => {
                dispatch(apiReducer({ apiData: e?.data, isLoading: false, }));
            })
            .catch((e) => {
                dispatch(apiReducer({ isLoading: false }));
            });
    };
}


export function userAddProjectApi(payload) {
    return apiHelper(userAddProjectReducer, "POST", "/api/user/projects", payload);
}

export function userProjectListApi(payload) {
    return apiHelper(userProjectListReducer, "GET", "/api/user/projects/all", payload);
}

export function userViewSingleProjectApi(payload) {
    return apiHelper(userViewSingleProjectReducer, "GET", `/api/user/projects/${payload}`);
}

export function userAddMilestoneApi(payload,projectRefId) {
    return apiHelper(userAddMilestoneReducer, "POST", `/api/user/projects/${projectRefId}/milestones/add`,payload);
}

export function getMilestonesByProjectForUserApi(projectRefId) {
    return apiHelper(getMilestonesByProjectForUserReducer, "GET", `/api/user/projects/${projectRefId}/milestones`);
}

export function updateMilestonesByProjectForUserApi(projectRefId,payload) {
    return apiHelper(updateMilestonesByProjectForUserReducer, "PUT", `/api/user/projects/${projectRefId}/milestones/edit`,payload);
}