import UserHome from '../../pages/user/Home'
import RootLayout from '../nav/rootLayout'
import AddNewProject from '../../componenets/user/AddProjects'
import ProjectList from '../../pages/user/ProjectList'
import MileStones from '../../pages/user/Milestones'
import ProjectOverview from '../../componenets/user/ProjectOverview'
import AddMileStone from '../../componenets/user/AddMilestone'
import UpdateMilestone from '../../componenets/user/UpdateMilestone'
import ViewMilestone from '../../componenets/user/UpdateMilestone'

const UserRoutes = [
  {
    path: "/userDashboard",
    element: <RootLayout />,
    children: [
      {
        path: "home",
        element: <UserHome />,
      },
      {
        path: "projects",
        element: <ProjectList />,
      },
      // {
      //   path: "mileStones",
      //   element: <MileStones />,
      // },
      {
        path: "addNewProject",
        element: <AddNewProject />,
      },
      {
        path: "viewProject",
        element: <ProjectOverview />,
      },
      {
        path: "addMilestones",
        element: <AddMileStone />,
      },
      {
        path: "viewMilestones",
        element: <ViewMilestone />,
      },

    ],
  }
]

export default UserRoutes