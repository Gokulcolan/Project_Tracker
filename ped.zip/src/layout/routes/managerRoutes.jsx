import React from 'react'
import ManagerHome from '../../pages/manager/Home'
import RootLayout from '../nav/rootLayout'

const ManagerRoutes = [
  {
    path: "/managerDashboard",
    element: <RootLayout />,
    children: [
      {
        path: "home",
        element: <ManagerHome />,
      },

    ],
  }
]

export default ManagerRoutes